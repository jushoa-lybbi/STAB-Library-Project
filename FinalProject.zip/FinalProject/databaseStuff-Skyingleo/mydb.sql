
-- CREATE TABLE userClass (
--     level INT NOT NULL,
--     bedit BOOLEAN NOT NULL,
--     comment BOOLEAN NOT NULL,
--     cedit BOOLEAN NOT NULL,
--     PRIMARY KEY(level)
--     );


-- CREATE TABLE user (
--     id INT AUTO_INCREMENT NOT NULL,
--     firstN VARCHAR(255) NOT NULL,
--     lastN VARCHAR(255) NOT NULL,
--     grade INT,
--     advisor TEXT,
--     email1 TEXT,
--     email2 TEXT,
--     veracross INT NOT NULL,
--     class INT NOT NULL,
--     history TEXT,
--     preference TEXT,
--     PRIMARY KEY(id),
--     FOREIGN KEY (class)
--         REFERENCES userClass (level)
--     );


-- CREATE TABLE book (
--     id INT AUTO_INCREMENT NOT NULL,
--     title VARCHAR(255) NOT NULL,
--     author VARCHAR(255) NOT NULL,
--     callN VARCHAR(100) NOT NULL,
--     barCode VARCHAR(255) NOT NULL,
--     status INT,
--     location TEXT,
--     sublocation TEXT,
--     glimit INT,
--     idate DATE,
--     ddate DATE,
--     catagoryid INT,
--     PRIMARY KEY(id),
--     FOREIGN KEY (status) REFERENCES user (id),
--     FOREIGN KEY (catagoryid) REFERENCES catagory(id)
--     );

-- CREATE TABLE catagory (
--     id into NOT NULL,
--     classRE TEXT,
--     PRIMARY KEY(id)
-- );