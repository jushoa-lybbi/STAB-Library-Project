const fs = require('fs');
const express = require('express');

const app = express();
const server = require('http').createServer(app);
const io = require('socket.io')(server);

const mustache = require('mustache-express');

app.get('/', function (req, res) {
  res.render('library', {});
});

app.get('/search', function (req, res) {
  res.render('search', {});
});

app.use(express.static(__dirname + "/public"));
app.set("views", __dirname + "/views");
app.set("view engine", "mustache");
app.engine("mustache", mustache());

server.listen(8080, () => {
	console.log("Server is online");
	});