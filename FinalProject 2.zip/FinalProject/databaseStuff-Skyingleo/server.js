const express = require('express');
const mustache = require('mustache-express');
const app = express();
const server = require('http').createServer(app);
const io = require('socket.io')(server);
const bcrypt = require('bcrypt');
const saltRounds = 10;
const myPlaintextPassword = 's0/\/\P4$$w0rD';
const someOtherPlaintextPassword = 'not_bacon';

let nBook = 0;
let allbID = [];
let allbarC =[];
let allTitle = [];
let allAuthor = [];
let allCallN = [];
let allStatus = [];
let allLocation = [];
let allsublocation = [];
let allGlimit = [];

let allBook = [];

// for (let a = 0; a < nBook; a++){
// 	allBook[a] = 
// 	"Book ID: " + allbID[a] + 
// 	"Title: " + allTitle[a] + 
// 	"Author: " + allAuthor[a] + 
// 	"Call Number: " + allCallN[a] + 
// 	"Status: " + allStatus[a] + 
// 	"Which Campus: " + allLoaction[a] + 
// 	"Location: " + allsublocation[a] + 
// 	"Grade Limit: " + allGlimit[a];
// }

let nUser = 0;
let alluID = [];
let allFirstN = [];
let allLastN = [];
let allGrade = [];
let allAdviser = [];
let allEmail1 = [];
let allEmail2 = [];
let allVeracross = [];
let allClass = [];

let allUser = [];

let newUser;
let newBook;
let BSearchR;
let USearchR;

let search;
let result;
let Epassord;
// for (let b = 0; b < nUser; b++){
// 	allUser[b] = 
// 	"User ID: " + alluID[b] + 
// 	"First Name: " + allFirstN[b] + 
// 	"Lat Names: " + allLastN[b] + 
// 	"Grade: " + allGrade[b] + 
// 	"Advisor: " + allAdviser[b] + 
// 	"Email 1: " + allEmail1[b] + 
// 	"Email 2: " + allEmail2[b] + 
// 	"Veracross Number: " + allVeracross[b] +
// 	"User's access level: " + allClass[b];
// }
const mysql = require("mysql2");
const connection = mysql.createConnection({
    host: "localhost",
    user: "my_user",
    password: "my_password123",
    database: "ldb"
});

// var sqlite3 = require('sqlite3');
// //const mysql = require('mysql2');
// let db = new sqlite3.Database('./file.db', sqlite3.OPEN_READWRITE, (err) => {
// 	if(err)
// 		console.log(err);

// 	console.log("conneted!");
// });

app.use(express.static("./public"));
app.set('views', "./views");
app.set('view engine', 'mustache');
app.engine('mustache', mustache());

//db.run(`DROP TABLE IF EXISTS messageHistory;`);
//db.run(`DROP TABLE IF EXISTS book;`);
//db.run(`DROP TABLE IF EXISTS user;`);

// connection.query(``);

// connection.query(``);

// connection.query(``);

//db.run("CREATE TABLE messageHistory (message TEXT);");
//db.run("INSERT INTO messageHistory VALUES (?);", ["What's up guys"]);
//db.run("INSERT INTO messageHistory VALUES ('Not much');");
//db.run("DELETE FROM messageHistory;");
// dispatch query for first two rows in messageHistory table

connection.query("SELECT id FROM book;", (err, bIDs) => {

	nBook = bIDs.length;

	for(let i = 0; i < bIDs.length; i++){
		allbID[i] = bIDs[i].id;
	}
	//console.log(allbID);
	//console.log("123");
});

connection.query("SELECT title FROM book;", (err, titles) => {

	for(let i = 0; i < titles.length; i++){
		allTitle[i] = titles[i].title;
	}
	//console.log(allTitle);
});

connection.query("SELECT author FROM book;", (err, authors) => {

	for(let i = 0; i < authors.length; i++){
		allAuthor[i] = authors[i].author;
	}
	//console.log(allTitle);
});

connection.query("SELECT callN FROM book;", (err, callNs) => {

	for(let i = 0; i < callNs.length; i++){
		allCallN[i] = callNs[i].callN;
	}
	//console.log(allTitle);
});

connection.query("SELECT status FROM book;", (err, statuss) => {

	for(let i = 0; i < statuss.length; i++){
		if (statuss[i].status == null){
			allStatus[i] = 'available';
		}
		else{
			allStatus[i] = statuss[i].status;
		}
	}
	//console.log(allTitle);
});

connection.query("SELECT location FROM book;", (err, locations) => {

	for(let i = 0; i < locations.length; i++){
		if (locations[i].location == null){
			allLocation[i] = "unknown";
		}
		else{
			allLocation[i] = locations[i].location;
		}
		
	}
	//console.log(allTitle);
});

connection.query("SELECT sublocation FROM book;", (err, sublocations) => {

	for(let i = 0; i < sublocations.length; i++){
		if (sublocations[i].sublocation == null){
			allsubLocation[i] = "unknown";
		}
		else{
			allsublocation[i] = sublocations[i].sublocation;
		}
	}
	//console.log(allTitle);
});

connection.query("SELECT glimit FROM book;", (err, glimits) => {

	for(let i = 0; i < glimits.length; i++){
		if (glimits[i].glimit == null){
			allGlimit[i] = "none";
		}
		else{
			allGlimit[i] = glimits[i].glimit;
		}
	}
	//console.log(allTitle);
});


connection.query("SELECT id FROM user;", (err, uIDs) => {

	nUser = uIDs.length;

	for(let i = 0; i < uIDs.length; i++){
		alluID[i] = uIDs[i].id;
	}
	//console.log(alluID);
});

connection.query("SELECT firstN FROM user;", (err, firstNs) => {

	for(let i = 0; i < firstNs.length; i++){
		allFirstN[i] = firstNs[i].firstN;
	}
});

connection.query("SELECT lastN FROM user;", (err, lastNs) => {

	for(let i = 0; i < lastNs.length; i++){
		allLastN[i] = lastNs[i].lastN;
	}
});

connection.query("SELECT grade FROM user;", (err, grades) => {

	for(let i = 0; i < grades.length; i++){
		if (grades[i].grade == null){
			allGrade[i] = "unknown";
		}
		else{
			allGrade[i] = grades[i].grade;
		}
	}
});

connection.query("SELECT advisor FROM user;", (err, advisors) => {

	for(let i = 0; i < advisors.length; i++){
		if (advisors[i].advisor == null){
			allAdviser[i] = "unknown";
		}
		else{
			allAdviser[i] = advisors[i].advisor;
		}
	}
});

connection.query("SELECT email1 FROM user;", (err, email1s) => {

	for(let i = 0; i < email1s.length; i++){
		if (email1s[i].email1 == null){
			allEmail1[i] = "unknown";
		}
		else{
			allEmail1[i] = email1s[i].email1;
		}
	}
});

connection.query("SELECT email2 FROM user;", (err, email2s) => {

	for(let i = 0; i < email2s.length; i++){
		if (email2s[i].email2 == null){
			allEmail2[i] = "unknown";
		}
		else{
			allEmail2[i] = email2s[i].email2;
		}
	}
});

connection.query("SELECT veracross FROM user;", (err, veracrosss) => {
	
	for(let i = 0; i < veracrosss.length; i++){
		allVeracross[i] = veracrosss[i].veracross;
	}
});

connection.query("SELECT class FROM user;", (err, classs) => {

	for(let i = 0; i < classs.length; i++){
		allClass[i] = classs[i].class;
	}
});

app.get("/", (req, res) => {
	res.render('home');

});

io.on("connection", (socket) => {
	console.log("User: " + socket.id + " conneted"); 

	
	socket.on('bSent', async function (titlec, authorc, callNc, statusc, locationc, sublocationc, glimitc, catagoryidc, barCodec, datec, seriesc){
		//allbarC.push(barCodec);
		search = barCodec;
		try{
			await new Promise((resolve, reject) => {
				connection.query('INSERT INTO book(title, author, callN, status, location, sublocation, glimit, catagoryid, barCode, date, series) VALUES (?,?,?,?,?,?,?,?,?,?,?);', [titlec, authorc, callNc, statusc, locationc, sublocationc, glimitc, catagoryidc, barCodec, datec, seriesc], (error, result) => {
					if (error) return reject(error); // UH OH WEEWWOOOO
					console.log('new book added');
					socket.emit('Nbook', "new book: " + connection.query('select * from book where barCode = ?', search));
					resolve(result);
				});
			});
		} catch(error){
			console.log(error);
		}

		
		//io.emit('barCoder', barCodecs);

	});

 

	socket.on('uSent', async function (firstNc, lastNc, gradec, advisorc, email1c, email2c, veracrossc, classc, Pwordc, Unamec){
		//alluID.push(uIDc);
		search = lastNc;
		Epassord = Pwordc;
		bcrypt.hash(Epassord, saltRounds, function(err, hash) {
    		Epassord = hash;
 		});
		try{
			await new Promise((resolve, reject) => {
				connection.query("INSERT INTO user(firstN,lastN,grade,advisor,email1,email2,veracross,class,password,username) VALUES (?,?,?,?,?,?,?,?,?,?);", [firstNc, lastNc, gradec, advisorc, email1c, email2c, veracrossc, classc, Epassord, Unamec], (error, result) => {
					if (error) return reject(error); // UH OH WEEWWOOOO
					console.log('new user created');
					socket.emit('Nuser', "new user: " + connection.query('select * from user where lastN = ?', search));
					resolve(result);

				});
			});
		} catch(error){
			console.log(error);
		}

		
		//io.emit('barCoder', barCodecs);

	});


	socket.on('sbBSent', async function (sbB){
		search = sbB;
		//console.log("message recieved");
		try{
			let result = await new Promise((resolve, reject) => {
				connection.query("select * from book where barCode = ?", search, (error, result) => {
					if (error) return reject(error); // UH OH WEEWWOOOO
					
					resolve(result);
				});
			});
			socket.emit('Sresult', result);
			//console.log(result);

		} catch(error){
			console.log(error);
		}

	});

	socket.on('sbTSent', async function (sbT){
		search = sbT;
		//console.log("message recieved");
		try{
			let result = await new Promise((resolve, reject) => {
				connection.query(`select * from book;`, (book, error, result) => {
					if (error) return reject(error);
					let i;
					for(i in book){
						if(editDistance(book(i).title, search) < 4)
							
							resolve(result);
							break;
					}
				console.log(i);
			});
			});
			socket.emit('Sresult', result);
			console.log(result);

		} catch(error){
			console.log(error);
		}

	});

	socket.on('sbASent', async function (sbA){
		search = sbA;
		//console.log("message recieved");
		try{
			let result = await new Promise((resolve, reject) => {
				connection.query(`select * from book;`, (book, error, result) => {
					if (error) return reject(error);
					let i;
					for(i in book){
						if(editDistance(book(i).author, search) < 4)
							
							resolve(result);
							break;
					}
				console.log(i);
			});
			});

			BSearchR = result; 
			BSearchR.catagoryid = 
			if (BSearchR.)
			socket.emit('Sresult', result);
			console.log(result);

		} catch(error){
			console.log(error);
		}

	});


	
});


// I got this edit distance from https://stackoverflow.com/a/36566052
function editDistance(s1, s2) {
  s1 = s1.toLowerCase();
  s2 = s2.toLowerCase();

  var costs = new Array();
  for (var i = 0; i <= s1.length; i++) {
    var lastValue = i;
    for (var j = 0; j <= s2.length; j++) {
      if (i == 0)
        costs[j] = j;
      else {
        if (j > 0) {
          var newValue = costs[j - 1];
          if (s1.charAt(i - 1) != s2.charAt(j - 1))
            newValue = Math.min(Math.min(newValue, lastValue),
              costs[j]) + 1;
          costs[j - 1] = lastValue;
          lastValue = newValue;
        }
      }
    }
    if (i > 0)
      costs[s2.length] = lastValue;
  }
  return costs[s2.length];
}





server.listen(8080, () => {
	console.log("server go vroom");
});
