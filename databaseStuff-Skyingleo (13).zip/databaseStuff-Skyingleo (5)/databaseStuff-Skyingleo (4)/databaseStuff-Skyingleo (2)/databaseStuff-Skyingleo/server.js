const express = require('express');
const mustache = require('mustache-express');
const app = express();
const server = require('http').createServer(app);
const io = require('socket.io')(server);
const bcrypt = require('bcrypt');
const saltRounds = 10;
const myPlaintextPassword = 's0/\/\P4$$w0rD';
const someOtherPlaintextPassword = 'not_bacon';

const csv = require ('csvtojson');

// const converter = csv()
// 	.fromFile('./data.csv')
// 	.then((json) => {
// 		console.log(json);
// 		for (let i= 0; i < json.length; i++){
// 			connection.query("INSERT into book (title, barCode, author, publisher) VALUES (?,?,?,?);",[json[i].titles, json[i].subtitles, json[i].authors, json[i].publishers])
// 		}
// 	});



let nBook = 0;
let allbID = [];
let allbarC =[];
let allTitle = [];
let allAuthor = [];
let allCallN = [];
let allStatus = [];
let allLocation = [];
let allsublocation = [];
let allGlimit = [];

let allBook = [];

// for (let a = 0; a < nBook; a++){
// 	allBook[a] = 
// 	"Book ID: " + allbID[a] + 
// 	"Title: " + allTitle[a] + 
// 	"Author: " + allAuthor[a] + 
// 	"Call Number: " + allCallN[a] + 
// 	"Status: " + allStatus[a] + 
// 	"Which Campus: " + allLoaction[a] + 
// 	"Location: " + allsublocation[a] + 
// 	"Grade Limit: " + allGlimit[a];
// }

let nUser = 0;
let alluID = [];
let allFirstN = [];
let allLastN = [];
let allGrade = [];
let allAdviser = [];
let allEmail1 = [];
let allEmail2 = [];
let allVeracross = [];
let allClass = [];

let allUser = [];

let newUser;
let newBook;
let BSearchR;
let USearchR;

let search;
let result;
let Epassord;

let editID;
let cstitle;
// for (let b = 0; b < nUser; b++){
// 	allUser[b] = 
// 	"User ID: " + alluID[b] + 
// 	"First Name: " + allFirstN[b] + 
// 	"Lat Names: " + allLastN[b] + 
// 	"Grade: " + allGrade[b] + 
// 	"Advisor: " + allAdviser[b] + 
// 	"Email 1: " + allEmail1[b] + 
// 	"Email 2: " + allEmail2[b] + 
// 	"Veracross Number: " + allVeracross[b] +
// 	"User's access level: " + allClass[b];
// }
const mysql = require("mysql2");
const connection = mysql.createConnection({
    host: "localhost",
    user: "my_user",
    password: "my_password123",
    database: "ldb"
});

// var sqlite3 = require('sqlite3');
// //const mysql = require('mysql2');
// let db = new sqlite3.Database('./file.db', sqlite3.OPEN_READWRITE, (err) => {
// 	if(err)
// 		console.log(err);

// 	console.log("conneted!");
// });

app.use(express.static("./public"));
app.set('views', "./views");
app.set('view engine', 'mustache');
app.engine('mustache', mustache());

//db.run(`DROP TABLE IF EXISTS messageHistory;`);
//db.run(`DROP TABLE IF EXISTS book;`);
//db.run(`DROP TABLE IF EXISTS user;`);

// connection.query(``);

// connection.query(``);

// connection.query(``);

//db.run("CREATE TABLE messageHistory (message TEXT);");
//db.run("INSERT INTO messageHistory VALUES (?);", ["What's up guys"]);
//db.run("INSERT INTO messageHistory VALUES ('Not much');");
//db.run("DELETE FROM messageHistory;");
// dispatch query for first two rows in messageHistory table



app.get("/", (req, res) => {
	res.render('home');

});

io.on("connection", (socket) => {
	console.log("User: " + socket.id + " conneted"); 

	
	socket.on('bSent', async function (titlec, authorc, callNc, statusc, locationc, sublocationc, glimitc, catagoryidc, barCodec, datec, seriesc, publishc){
		//allbarC.push(barCodec);
		search = barCodec;
		if (datec == null || datec == "" || datec == undefined){
			datec = new Date();
		}
		
		try{
			await new Promise((resolve, reject) => {
				connection.query('INSERT INTO book(title, author, callN, status, location, sublocation, glimit, catagoryid, barCode, date, series, publisher) VALUES (?,?,?,?,?,?,?,?,?,?,?,?);', [titlec, authorc, callNc, statusc, locationc, sublocationc, glimitc, catagoryidc, barCodec, datec, seriesc, publishc], (error, result) => {
					if (error) return reject(error); // UH OH WEEWWOOOO
					console.log('new book added');
					socket.emit('Nbook', "new book added");
					resolve(result);
				});
			});
		} catch(error){
			console.log(error);
		}

		
		//io.emit('barCoder', barCodecs);

	});

 

	socket.on('uSent', async function (firstNc, lastNc, gradec, advisorc, email1c, email2c, veracrossc, classc){
		let search = lastNc;
		let uName = firstNc + " " + lastNc;
		try{
			await new Promise((resolve, reject) => {
				connection.query("INSERT INTO user(firstN,lastN,grade,advisor,email1,email2,veracross,class,username) VALUES (?,?,?,?,?,?,?,?,?);", [firstNc, lastNc, gradec, advisorc, email1c, email2c, veracrossc, classc, uName], (error, result) => {
					if (error) return reject(error); // UH OH WEEWWOOOO
					console.log('new user created');
					socket.emit('Nuser', "new user created");
					resolve();

				});
			});
		} catch(error){
			console.log(error);
		}

		
		//io.emit('barCoder', barCodecs);

	});


	socket.on('sbBSent', async function (sbB){
		search = sbB;
		console.log("message recieved");
		try{
			let result = await new Promise((resolve, reject) => {
				connection.query('SELECT a.*,b.class,c.username, d. school FROM book a LEFT JOIN category b ON a.catagoryid = b.id LEFT JOIN user c ON a.STATUS=c.id LEFT JOIN campus d ON a.location = d.id where barCode = ?;', search, (error, result) => {
					if (error) return reject(error); // UH OH WEEWWOOOO
					
					resolve(result);
				});
			});
			//clearification(result);
			socket.emit('Sresult', result);
			//socket.emit('Sresult', result);
			//console.log(result);

		} catch(error){
			console.log(error);
		}

	});

	socket.on('sbTSent', async function (sbT){
		search = sbT;
		let bookL = [];
		console.log("T recieved");
		try{
			await new Promise((resolve, reject) => {
				connection.query('SELECT a.*,b.class, c.username, d. school FROM book a LEFT JOIN category b ON a.catagoryid = b.id LEFT JOIN user c ON a.STATUS=c.id LEFT JOIN campus d ON a.location = d.id;', (error, book, result) => {
					if (error) return reject("something went wrong... maybe we don't have that book",error);
					//console.log("T book", book);
					for(let i in book){
						if(editDistance(book[i].title, search) < 4){
							bookL.push(book[i]);
						}
					}

					resolve();
					
				//console.log(i);
			});
				
			});
			console.log("submit result");
			socket.emit('Sresult', bookL);

		} catch(error){
			console.log("uhhh oh", error);
		}

	});

	socket.on('cssbTSent', async function (cssbT){
		let search = cssbT;
		let bookL = [];
		cstitle = cssbT;
		console.log("cs T recieved");
		try{
			await new Promise((resolve, reject) => {
				connection.query('SELECT a.*,b.class, c.username, d. school FROM book a LEFT JOIN category b ON a.catagoryid = b.id LEFT JOIN user c ON a.STATUS=c.id LEFT JOIN campus d ON a.location = d.id;', (error, book, result) => {
					if (error) return reject("something went wrong... maybe we don't have that book",error);
					//console.log("T book", book);
					for(let i in book){
						if(editDistance(book[i].title, search) < 1){
							bookL.push(book[i]);
						}
					}

					resolve();
					
				//console.log(i);
			});
				
			});
			console.log("submit result");
			socket.emit('csSresult', bookL);

		} catch(error){
			console.log("uhhh oh", error);
		}

	});

	socket.on('sbASent', async function (sbA){
		search = sbA;
		let bookL = [];
		//console.log("message recieved");
		try{
			await new Promise((resolve, reject) => {
				connection.query(`SELECT a.*,b.class,c.username, d. school FROM book a LEFT JOIN category b ON a.catagoryid = b.id LEFT JOIN user c ON a.STATUS=c.id LEFT JOIN campus d ON a.location = d.id;`, (error, book, result) => {
					if (error) return reject(error);
					
					for(let i in book){
						if(editDistance(book[i].author, search) < 4){
							bookL.push(book[i]);
							
						}
					}
					resolve();
					
				//console.log(i);
			});
			});

			socket.emit('Sresult', bookL);

			
			console.log(result);

		} catch(error){
			console.log(error);
		}

	});

	socket.on('lbrequest', async function (BID, UID){
		search = BID;
		let lender = UID;
		try{
			await new Promise(async (resolve, reject) =>{
				let initial = new Date();
				let due = new Date(initial.getTime() + 1210000000);
				console.log(due);
				let availablity = await new Promise((avail_resolve, avail_reject) => {
					connection.query('select * from book where id = ?', BID, (err, res) => {
						if (err) return reject(err);
						avail_resolve(res);
					});
				});
				console.log(availablity[0]);
				console.log(availablity[0].status);
				if (availablity[0].status == 1){
					connection.query('update book set status = ?, idate = ?, ddate = ? where id = ?;', [lender,initial,due,search], (error, result) => {
						if (error) return reject(error);
						socket.emit('lbrespond', "You got it YaY");
						resolve();
					});
				} else {
					socket.emit('lbrespond', "Sorry... Someone has it still...");
				}
			});
			
		} catch(error){
			console.log(error);
		}
	});

	socket.on('rList', async function (UID){
		let returner = UID;
		let bookL = [];
		try{
			await new Promise((resolve, reject) => {
				connection.query(`SELECT a.*,b.class,c.username, d. school FROM book a LEFT JOIN category b ON a.catagoryid = b.id LEFT JOIN user c ON a.STATUS=c.id LEFT JOIN campus d ON a.location = d.id;`, (error, book, result) => {
					if (error) return reject(error);
					
					for(let i in book){
						if(book[i].status == UID){
							bookL.push(book[i]);
							console.log(book[i].id);

						}
					}
					
					resolve();
					
				//console.log(i);
			});
			});
			console.log(bookL);

			socket.emit('canRr', bookL);
		} catch (error){
			console.log(error);
		}
	});

	socket.on('returnRequest', async function (BID){
		let returnB = BID;
		try{
			await new Promise((resolve, reject) =>{
				connection.query('update book set status = ?, idate = ?, ddate = ? where id = ?;', [1,null,null,BID], (error, result) => {
						if (error) return reject(error);
						socket.emit('returnDone', "You just return it YaY");
						resolve();
					});
			});
		} catch (error){
			console.log(error);
		}
	});

	socket.on('newD', async function (nD){
		let input = nD;
		console.log(input);
		try{
			await new Promise((resolve,reject) => {
				connection.query('update book set description = ? where title = ?;', [input, cstitle], (error, result) =>{
					if (error) return reject(error);
					socket.emit('newDDone', "description added");
					resolve();
				});
			});
		} catch (error){
			console.log(error);
		}
	});

	socket.on('newC', async function (nC){
		let input = nC;
		console.log(input);
		try{
			await new Promise((resolve,reject) => {
				connection.query('update book set comment = ? where title = ?;', [input, cstitle], (error, result) =>{
					if (error) return reject(error);
					socket.emit('newCDone', "comment added");
					resolve();
				});
			});
		} catch (error){
			console.log(error);
		}
	});
});

//  SELECT a.*,b.class,c.username, d. school FROM book a LEFT JOIN category b ON a.catagoryid = b.id LEFT JOIN user c ON a.STATUS=c.id LEFT JOIN campus d ON a.location = d.id WHERE b.id = "1"  and c.id=1 and d. id =1;

// async function clearification(Robj){
// 	for (let i = 0; i < Robj.length; i++){
// 		if(Robj[i].series == "" || Robj[i].series == null){
// 			Robj[i].series = "This book does not belong to any series";
// 		}
// 		if(Robj[i].status == 1){
// 			Robj[i].status = "Available";
// 			Robj[i].idate = "none";
// 			Robj[i].ddate = "none";
// 			Robj[i].userN = "No one has it, borrow it now :D";
// 		}else {
// 			try{
// 				let result = await new Promise((resolve, reject) => {
// 						connection.query("select username from user where id = ?", Robj[i].status, (error, result) => {
// 							if (error) return reject(error); // UH OH WEEWWOOOO
							
// 							resolve(result);
// 						});
// 					});
// 			}catch(error){
// 				console.log(error);
// 			}
// 			Robj[i].status = "Not available";
// 			Robj[i].userN = result;
// 		}
// 		if(Robj[i].location == 0){
// 			Robj[i].location = "Lower School";
// 		}else {
// 			Robj[i].location = "Upper School";
// 		}
// 		if(Robj[i].sublocation == "" || Robj[i].sublocation == null){
// 			Robj[i].sublocation = "no where to be found :)";
// 		}
// 		if(Robj[i].catagoryid != "" || Robj[i].catagoryid != null){
// 			try	{
// 				let result = await new Promise((resolve, reject) => {
// 						connection.query("select class from category where id = ?", Robj[i].catagoryid, (error, result) => {
// 							if (error) return reject(error); // UH OH WEEWWOOOO
							
// 							resolve(result);
// 						});
// 					});
// 			}catch(error){
// 				console.log(error);
// 			}

// 			Robj[i].catagoryid = result;
// 		}else {
// 			Robj[i].catagoryid = "not belong to any sepcific type";
// 		}
// 		if(Robj[i].comment == "" || Robj[i].comment == null){
// 			Robj[i].comment = "no comments";
// 		}
// 		if(Robj[i].description == "" || Robj.description == null){
// 			Robj[i].comment = "no description";
// 		}
// 		socket.emit('Sresult', result);
// 	}
// }

// I got this edit distance from https://stackoverflow.com/a/36566052
function editDistance(s1, s2) {
  s1 = s1.toLowerCase();
  s2 = s2.toLowerCase();

  var costs = new Array();
  for (var i = 0; i <= s1.length; i++) {
    var lastValue = i;
    for (var j = 0; j <= s2.length; j++) {
      if (i == 0)
        costs[j] = j;
      else {
        if (j > 0) {
          var newValue = costs[j - 1];
          if (s1.charAt(i - 1) != s2.charAt(j - 1))
            newValue = Math.min(Math.min(newValue, lastValue),
              costs[j]) + 1;
          costs[j - 1] = lastValue;
          lastValue = newValue;
        }
      }
    }
    if (i > 0)
      costs[s2.length] = lastValue;
  }
  return costs[s2.length];
}





server.listen(8080, () => {
	console.log("server go vroom");
});
