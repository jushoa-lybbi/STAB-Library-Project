//setInterval(run, 2000);
const socket = io();
const Title = document.getElementById("Title");

let Author = document.getElementById("Author");
//const cTree = document.getElementsByClassName("body-bg");
let bdisplay = document.getElementById("bdisplay");

let barCode = document.getElementById("barCode");
let title = document.getElementById("title");
let author = document.getElementById("author");
let callN = document.getElementById("callN");
let status = document.getElementById("status");
let llocation = document.getElementById("llocation");
let sublocation = document.getElementById("sublocation");
let glimit = document.getElementById("glimit");
let date = document.getElementById("date");
let series = document.getElementById("series");
let publish = document.getElementById("publish");


let udisplay = document.getElementById("udisplay");

let firstN = document.getElementById("firstN");
let lastN = document.getElementById("lastN");
let grade = document.getElementById("grade");
let advisor = document.getElementById("advisor");
let email1 = document.getElementById("email1");
let email2 = document.getElementById("email2");
let veracross = document.getElementById("veracross");
let uclass = document.getElementById("uclass");
// let Uname = document.getElementById("Uname");
// let Pword = document.getElementById("Pword");


let searchBInput = document.getElementById("searchBInput");
let bookR = document.getElementById("bookR");
let lend = document.getElementById("Lend");
let BC = document.getElementById("BC");
let Bchoices = document.getElementById("Bchoices");
let Uinput = document.getElementById("Uinput");

let cAndD = document.getElementById("cAndD");
let csInput = document.getElementById("csInput");
let cssbTEnter = document.getElementById("cssbTEnter");
let descriptionInput = document.getElementById("descriptionInput");
let saveD = document.getElementById("saveD");
let commentInput = document.getElementById("commentInput");
let saveC = document.getElementById("saveC");

let searchR;

let rBook = document.getElementById("rBook");
let returnD = document.getElementById("returnD");
let uIDreturn = document.getElementById("uIDreturn");
let uIDEnter = document.getElementById("uIDEnter");
let bIDreturn = document.getElementById("bIDreturn");
let bIDEnter = document.getElementById("bIDEnter");


//let edit = document.getElementById("edit");

socket.on("connect", (data) => {
	//console.log(data); // x8WIv7-mJelg7on_ALbx
	lend.style.display = "none";
	Bchoices.style.display = "none";
	BC.style.display = "none";
	Uinput.style.display = "none";
	bIDreturn.style.display = "none";
	bIDEnter.style.display = "none";
	descriptionInput.style.display = "none";
	saveD.style.display = "none";
	commentInput.style.display = "none";
	saveC.style.display = "none";
	//edit.style.display = "none";
});

console.log("connected!!!!");

$("#bEnter").click(function() {

	console.log($('#llocation').val());
	socket.emit('bSent', $('#title').val(), $('#author').val(), $('#callN').val(), $('#status').val(), $('#llocation').val(), $('#sublocation').val(), $('#glimit').val(), $('#catagoryid').val(), $('#barCode').val(), $('#date').val(), $('#series').val(), $('#publish').val());
})

$("#uEnter").click(function() {

	socket.emit('uSent', $('#firstN').val(), $('#lastN').val(), $('#grade').val(), $('#advisor').val(), $('#email1').val(), $('#email2').val(), $('#veracross').val(), $('#uclass').val());
})

$("#sbBEnter").click(function() {
	console.log("B sent!");
	socket.emit('sbBSent', $('#searchBInput').val());

})

$("#sbTEnter").click(function() {
	console.log("T sent!");
	socket.emit('sbTSent', $('#searchBInput').val());

})

$("#sbAEnter").click(function() {
	console.log("A sent!");
	socket.emit('sbASent', $('#searchBInput').val());

})

$("#cssbTEnter").click(function() {
	console.log("cs T sent!");
	socket.emit('cssbTSent', $('#csInput').val());
})

let rCategory;
let rSeries;
let rLoc;
let rSubloc;
let rCallN;
let rStatus;
let rDescrip;
let rComment;

$("#uIDEnter").click(function(){
	console.log("uid want to return book");
	socket.emit('rList', $('#uIDreturn').val())
})

//function 

socket.on('Nbook', function(data) {
	$('#bdisplay').empty();
	$('#bdisplay').append("<li>" + data + '</li>');
});

socket.on('lbrespond', function(data) {
	$('#bookR').empty();
	$('#bookR').append("<li>" + data + '</li>');
});

socket.on('Nuser', function(data) {
	$('#udisplay').empty();
	$('#udisplay').append("<li>" + data + '</li>');
});



socket.on('Sresult', function(data) {
	console.log("hshahahahha");
	searchR = data;
	$('#bookR').empty();
	// rCategory = data[i].catagoryid;
	if(data.length < 1){
		$('#bookR').append("something went wrong... we might not have that book ;(");
	}

	for (let i = 0; i < data.length; i++) {
		$('#bookR').append("<li>" + "Book id : " + data[i].id + " " + '</li>');
		$('#bookR').append("<li>" + "Title : " + data[i].title + " " + '</li>');
		$('#bookR').append("<li>" + "Author : " + data[i].author + " " + '</li>');
		$('#bookR').append("<li>" + "Which Catagory : " + data[i].class + " " + '</li>');
		$('#bookR').append("<li>" + "Which Series : " + data[i].series + " " + '</li>');
		$('#bookR').append("<li>" + "Which Campus : " + data[i].school + " " + '</li>');
		$('#bookR').append("<li>" + "Where Exactly : " + data[i].sublocation + " " + '</li>');
		$('#bookR').append("<li>" + "Grade Limit : " + data[i].glimit + " " + '</li>');
		$('#bookR').append("<li>" + "Date Lended : " + data[i].idate + " " + '</li>');
		$('#bookR').append("<li>" + "Due Date : " + data[i].ddate + " " + '</li>');
		$('#bookR').append("<li>" + "Date Stored : " + data[i].date + " " + '</li>');
		$('#bookR').append("<li>" + "Barcode : " + data[i].barCode + " " + '</li>');
		$('#bookR').append("<li>" + "Call Number :  " + data[i].callN + " " + '</li>');
		$('#bookR').append("<li>" + "Ownership :  " + data[i].status + " " + '</li>');
		$('#bookR').append("<li>" + "Description : " + data[i].description + " " + '</li>');
		$('#bookR').append("<li>" + "Comment : " + data[i].comment + " " + '</li>');
		$('#bookR').append("<li>" + "User Name : " + data[i].username + " " + '</li>');
		$('#bookR').append("<li>" + "----------------------------" + '</li>');
	}

	if (lend.style.display == "none"){
		lend.style.display = "block";
		Bchoices.style.display = "none";
		BC.style.display = "none";
		Uinput.style.display = "block";
		//edit.style.display = "block";
	} else {
		lend.style.display = "none";
	}

	
});

// edit.onclick = function () {

// }

lend.onclick = function () {
	console.log("lending");
	console.log(searchR);
	lend.style.display = "none";


	if(searchR.length <= 1){
		if(searchR[0].status == 1){
			$('#bookR').empty();
			$('#bookR').append("<li>" + "Request Sent!" + '</li>');
			socket.emit('lbrequest', searchR[0].id, $('#Uinput').val());
		} else {
			$('#bookR').empty();
			$('#bookR').append("<li>" + "Uhh ohh... Some one has it already" + '</li>');
		}
	} else {
		BC.style.display = "block";
		Bchoices.style.display = "block";
		Uinput.style.display = "block";
	}

};

BC.onclick = function(){
	socket.emit('lbrequest', $('#Bchoices').val(), $('#Uinput').val());
};

socket.on('canRr', function(data) {
	console.log(data);
	$('#returnD').empty();

	$('#returnD').append("<li>" + data + '</li>');
	if(data.length < 1){
		$('#returnD').append("something went wrong... we don't think you have any books to return ;(");
	}

	for (let i = 0; i < data.length; i++) {
		$('#returnD').append("<li>" + "Book id : " + data[i].id + " " + '</li>');
		$('#returnD').append("<li>" + "Title : " + data[i].title + " " + '</li>');
		$('#returnD').append("<li>" + "Author : " + data[i].author + " " + '</li>');
		$('#returnD').append("<li>" + "Which Catagory : " + data[i].class + " " + '</li>');
		$('#returnD').append("<li>" + "Which Series : " + data[i].series + " " + '</li>');
		$('#returnD').append("<li>" + "Which Campus : " + data[i].school + " " + '</li>');
		$('#returnD').append("<li>" + "Where Exactly : " + data[i].sublocation + " " + '</li>');
		$('#returnD').append("<li>" + "Grade Limit : " + data[i].glimit + " " + '</li>');
		$('#returnD').append("<li>" + "Date Lended : " + data[i].idate + " " + '</li>');
		$('#returnD').append("<li>" + "Due Date : " + data[i].ddate + " " + '</li>');
		$('#returnD').append("<li>" + "Date Stored : " + data[i].date + " " + '</li>');
		$('#returnD').append("<li>" + "Barcode : " + data[i].barCode + " " + '</li>');
		$('#returnD').append("<li>" + "Call Number :  " + data[i].callN + " " + '</li>');
		$('#returnD').append("<li>" + "Ownership :  " + data[i].status + " " + '</li>');
		$('#returnD').append("<li>" + "Description : " + data[i].description + " " + '</li>');
		$('#returnD').append("<li>" + "Comment : " + data[i].comment + " " + '</li>');
		$('#returnD').append("<li>" + "User Name : " + data[i].username + " " + '</li>');
		$('#returnD').append("<li>" + "----------------------------" + '</li>');
	}

	if (bIDreturn.style.display == "none"){
		bIDreturn.style.display = "block";
		bIDEnter.style.display = "block";
	} else {
		bIDreturn.style.display = "none";
		bIDEnter.style.display = "none";
	}
});

$('#bIDEnter').click(function(){
	socket.emit('returnRequest', $('#bIDreturn').val());
});

socket.on('returnDone', function(data){
	$('#returnD').empty();
	$('#returnD').append("<li>" + data + '</li>');
});

socket.on('csSresult', function(data) {
	console.log("hshahahahha");
	$('#cAndD').empty();
	// rCategory = data[i].catagoryid;
	if(data.length < 1){
		$('#cAndD').append("something went wrong... we might not have that book ;(");
	}

	for (let i = 0; i < data.length; i++) {
		$('#cAndD').append("<li>" + "Book id : " + data[i].id + " " + '</li>');
		$('#cAndD').append("<li>" + "Title : " + data[i].title + " " + '</li>');
		$('#cAndD').append("<li>" + "Author : " + data[i].author + " " + '</li>');
		$('#cAndD').append("<li>" + "Which Catagory : " + data[i].class + " " + '</li>');
		$('#cAndD').append("<li>" + "Which Series : " + data[i].series + " " + '</li>');
		$('#cAndD').append("<li>" + "Which Campus : " + data[i].school + " " + '</li>');
		$('#cAndD').append("<li>" + "Where Exactly : " + data[i].sublocation + " " + '</li>');
		$('#cAndD').append("<li>" + "Grade Limit : " + data[i].glimit + " " + '</li>');
		$('#cAndD').append("<li>" + "Date Lended : " + data[i].idate + " " + '</li>');
		$('#cAndD').append("<li>" + "Due Date : " + data[i].ddate + " " + '</li>');
		$('#cAndD').append("<li>" + "Date Stored : " + data[i].date + " " + '</li>');
		$('#cAndD').append("<li>" + "Barcode : " + data[i].barCode + " " + '</li>');
		$('#cAndD').append("<li>" + "Call Number :  " + data[i].callN + " " + '</li>');
		$('#cAndD').append("<li>" + "Ownership :  " + data[i].status + " " + '</li>');
		$('#cAndD').append("<li>" + "Description : " + data[i].description + " " + '</li>');
		$('#cAndD').append("<li>" + "Comment : " + data[i].comment + " " + '</li>');
		$('#cAndD').append("<li>" + "User Name : " + data[i].username + " " + '</li>');
		$('#cAndD').append("<li>" + "----------------------------" + '</li>');
	}

	if (descriptionInput.style.display == "none"){
		descriptionInput.style.display = "block";
		saveD.style.display = "block";
		commentInput.style.display = "block";
		saveC.style.display = "block";
	} else {
		descriptionInput.style.display = "none";
		saveD.style.display = "none";
		commentInput.style.display = "none";
		saveC.style.display = "none";
	}
});

$('#saveD').click(function(){
	socket.emit('newD', $('#descriptionInput').val());
});

$('#saveC').click(function(){
	console.log($('#conInput').val());
	socket.emit('newC', $('#commentInput').val());
	
});

socket.on('newDDone', function(data){
	$('#cAndD').empty();
	$('#cAndD').append("<li>" + data + '</li>');
});

socket.on('newCDone', function(data){
	$('#cAndD').empty();
	$('#cAndD').append("<li>" + data + '</li>');
});
// socket.on('count', function (data) {
//     $('.user-count').html(data);
// });

// socket.on('textline', function (data) {
//     console.log(data);
//     $('ul').append("<li>"+data+'</li>');
// });

// socket.on('bIDr', function (bIDv) {
//     console.log(bIDv);
//     $('').append("<li>"+data+'</li>');
// });

// socket.on('texthistory', function (data) {
//     console.log(data);
//     for (let i = 0; i < data.length; i++){
//         $('ul').append("<li>"+data[i]+'</li>');
//     }
// });
//<script.src = "/socket.io/socket.io.js">

// socket.on('count', function (data) {
//   $('.user-count').html(data);
// });

// socket.on('textline', function (data) {
// 	console.log(data);
//   	$('ul').append("<li>"+data+'</li>');
// });

// socket.on('bIDr', function (bIDv) {
// 	console.log(bIDv);
//   	$('').append("<li>"+data+'</li>');
// });

// socket.on('texthistory', function (data) {
// 	console.log(data);
// 	for (let i = 0; i < data.length; i++){
// 	  	$('ul').append("<li>"+data[i]+'</li>');
// 	}
// });
//<script.src = "/socket.io/socket.io.js"></script>